DROP TABLE spectateur;
DROP TABLE concert;
DROP TABLE salle;

DROP ROLE admin21_directeur;
DROP ROLE admin21_vendeur_tickets;
DROP ROLE admin21_spectateur;
DROP ROLE admin21_invite;
